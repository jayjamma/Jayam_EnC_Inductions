#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState


# Robot dimensions (from the URDF)
L1 = 0.35
L2 = 0.35
BASE_HEIGHT = 0.17


class ArmController(Node):

    def __init__(self):

        super().__init__("arm_controller")

        self.publisher = self.create_publisher(
            JointState,
            "/joint_states",
            10
        )

        # Initial end-effector position
        # Arm straight forward with all joints = 0
        self.current_x = L1 + L2
        self.current_y = 0.0
        self.current_z = BASE_HEIGHT

        self.get_logger().info("Arm Controller Started")

    ############################################################

    def publish_angles(self, base, shoulder, elbow):

        msg = JointState()

        msg.header.stamp = self.get_clock().now().to_msg()

        msg.name = [
            "base_yaw_joint",
            "shoulder_joint",
            "elbow_joint"
        ]

        msg.position = [
            base,
            shoulder,
            elbow
        ]

        self.publisher.publish(msg)

    ############################################################

    def inverse_kinematics(self, x, y, z):

        # Base rotation
        theta_base = math.atan2(y, x)

        # Convert to planar coordinates
        r = math.sqrt(x * x + y * y)

        z = z - BASE_HEIGHT

        D = math.sqrt(r * r + z * z)

        # Workspace check
        if D > (L1 + L2):
            return None

        if D < abs(L1 - L2):
            return None

        cos_theta2 = (
            D * D - L1 * L1 - L2 * L2
        ) / (2 * L1 * L2)

        # Numerical safety
        cos_theta2 = max(min(cos_theta2, 1.0), -1.0)

        # Elbow-down solution
        theta2 = math.acos(cos_theta2)

        theta1 = (
            math.atan2(z, r)
            -
            math.atan2(
                L2 * math.sin(theta2),
                L1 + L2 * math.cos(theta2)
            )
        )

        return theta_base, theta1, theta2

    ############################################################

    def run(self):

        while rclpy.ok():

            print("\n---------------------------")
            print("Current End Effector Position")
            print(f"x = {self.current_x:.3f}")
            print(f"y = {self.current_y:.3f}")
            print(f"z = {self.current_z:.3f}")

            axis = input("\nEnter axis (x/y/z): ").lower()

            if axis not in ["x", "y", "z"]:
                print("Invalid axis!")
                continue

            try:
                distance = float(input("Enter displacement (m): "))
            except ValueError:
                print("Invalid number!")
                continue

            # Copy current position
            target_x = self.current_x
            target_y = self.current_y
            target_z = self.current_z

            if axis == "x":
                target_x += distance

            elif axis == "y":
                target_y += distance

            elif axis == "z":
                target_z += distance

            print("\nTarget Position")
            print(f"x = {target_x:.3f}")
            print(f"y = {target_y:.3f}")
            print(f"z = {target_z:.3f}")

            solution = self.inverse_kinematics(
                target_x,
                target_y,
                target_z
            )

            if solution is None:

                print("\nERROR")
                print("Target is outside reachable workspace.")
                continue

            base, shoulder, elbow = solution

            print("\nJoint Angles")
            print(f"Base     : {math.degrees(base):.2f} deg")
            print(f"Shoulder : {math.degrees(shoulder):.2f} deg")
            print(f"Elbow    : {math.degrees(elbow):.2f} deg")

            self.publish_angles(
                base,
                shoulder,
                elbow
            )

            self.current_x = target_x
            self.current_y = target_y
            self.current_z = target_z

            rclpy.spin_once(self, timeout_sec=0.1)


############################################################


def main(args=None):

    rclpy.init(args=args)

    node = ArmController()

    node.run()

    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()
